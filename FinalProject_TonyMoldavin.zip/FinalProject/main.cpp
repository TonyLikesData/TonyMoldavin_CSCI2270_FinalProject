#include <iostream>
#include "Queue.h"
#include <sstream>
#include <cstdlib>


using namespace std;

void mainMenu();
void listMenu(int);
void checkInput1(string);
void checkInput2(string);
void checkInput3(string);
int checkProirity();

int main()
{

    Queue queuelist[10] = Queue(10);
    string input = "0";
    int i;

    mainMenu();
    getline(cin,input);
    checkInput1(input);

    while(input != "9")
    {
        if(input == "1")
        {
            i = checkProirity();
            string phrase;
            cout << "Enter task:" << endl;
            getline(cin, phrase);
            queuelist[i].enqueue(phrase);
        }
        else if(input == "2")
        {
            i = checkProirity();
            cout << "Deleted '" << queuelist[i].dequeue() << "' in list " << i << endl;
        }
        else if(input == "3")
        {
            i = checkProirity();
            queuelist[i].printTask();
        }
        else if(input == "4")
        {
            i = checkProirity();
            queuelist[i].printQueue();
        }
        else if(input == "5")
        {
            for(int j; j < 10; j++)
            {
                cout << "======List " << j << "======" << endl;
                queuelist[j].printQueue();
            }
        }
        else if(input == "6")
        {
            string inpt;

            i = checkProirity();
            listMenu(i);
            getline(cin,inpt);
            checkInput2(inpt);

            while(inpt != "5")
            {
                if(inpt == "1")
                {
                    string ph;

                    cout << "Enter task:" << endl;
                    getline(cin, ph);
                    queuelist[i].enqueue(ph);
                }
                else if(inpt == "2")
                {
                    cout << "Deleted '" << queuelist[i].dequeue() << "' in list " << i << endl;
                }
                else if(inpt == "3")
                {
                    queuelist[i].printQueue();
                }
                else if(inpt == "4")
                {
                    queuelist[i].dequeueAll();
                }

                listMenu(i);
                getline(cin,inpt);
                checkInput2(inpt);
            }
            if(inpt == "5")
            {
                cout << "Returning to Main Menu..." << endl;
            }
        }
        else if(input == "7")
        {
            i = checkProirity();
            queuelist[i].dequeueAll();
        }
        else if(input == "8")
        {
            for(int j; j < 10; j++)
            {
                queuelist[j].dequeueAll();
            }
        }
        mainMenu();
        getline(cin,input);
        checkInput1(input);
    }
    if(input == "9")
    {
        cout << "Goodbye!" << endl;
    }
}

void mainMenu()
{
    cout << "======Main Menu======" << endl;
    cout << "1. Enqueue task" << endl;
    cout << "2. Dequeue task" << endl;
    cout << "3. Print task" << endl;
    cout << "4. Print list" << endl;
    cout << "5. Print all lists" << endl;
    cout << "6. Select list" << endl;
    cout << "7. Delete list" << endl;
    cout << "8. Delete all lists" << endl;
    cout << "9. Quit" << endl;
}

void listMenu(int i)
{
    cout << "======List " << i+1 << " Menu======" << endl;
    cout << "1. Enqueue task" << endl;
    cout << "2. Dequeue task" << endl;
    cout << "3. Print all tasks" << endl;
    cout << "4. Delete all tasks" << endl;
    cout << "5. Quit" << endl;
}

void checkInput1(string i)
{
    if(i != "1" && i != "2" && i != "3" && i != "4" && i != "5" && i != "6" && i != "7" && i != "8" && i != "9")
    {
        cout << "Invalid input. Enter a number corresponding to the menu option of interest (1-9)." << endl;
    }
}

void checkInput2(string i)
{
    if(i != "1" && i != "2" && i != "3" && i != "4" && i != "5")
    {
        cout << "Invalid input. Enter a number corresponding to the menu option of interest (1-5)." << endl;
    }
}

void checkInput3(string i)
{
    if(i != "1" && i != "2" && i != "3" && i != "4" && i != "5" && i != "6" && i != "7" && i != "8" && i != "9" && i != "10")
    {
        cout << "Invalid input. Enter a number corresponding to the list number of interest (1-10)." << endl;
    }
}

int checkProirity()
{
    string in;
    cout << "Enter list number (1-10)" << endl;
    getline(cin,in);
    checkInput3(in);
    int i = atoi(in.c_str());
    return i-1;
}
