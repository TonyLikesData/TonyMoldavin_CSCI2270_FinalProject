#ifndef QUEUENODE_H
#define QUEUENODE_H
#include "Queue.h"


class QueueNode
{
public:
    QueueNode();
    QueueNode(std::string);
    ~QueueNode();
    void addQueueNode(Queue,std::string);
    void deleteQueueNode(std::string);
    void printQueueNode(std::string);
    void printAll();
    void deleteAll();
    void searchQueueNodes(std::string);
private:
};

#endif // QUEUENODE_H
