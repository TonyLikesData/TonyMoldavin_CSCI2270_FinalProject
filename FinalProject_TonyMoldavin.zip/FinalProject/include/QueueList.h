#ifndef QUEUELIST_H
#define QUEUELIST_H
#include "Queue.h"


struct Node
{
    std::string title;
    Queue q;
    Node *next;
    Node * prev;
};

class QueueList
{
public:
    QueueList();
    QueueList(std::string);
    ~QueueList();
    void addQueueList(Queue,std::string);
    void deleteQueueList(std::string);
    void printQueueList(std::string);
    void printAll();
    void deleteAll();
    void searchQueueLists(std::string);
private:
};

#endif // QueueList_H
