#include "QueueNode.h"
QueueNode::QueueNode()
{
    std::string title = "";
    Queue n = Queue(10);
    QueueNode *next = NULL;
    QueueNode *previous = NULL;
}

QueueNode::QueueNode(std::string ttl)
{
    //ctor
    std::string title = ttl;
    Queue n = Queue(10);
    QueueNode *next = NULL;
    QueueNode *previous = NULL;
}

QueueNode::~QueueNode()
{
    //dtor
}

void QueueNode::addQueueNode(Queue q, std::string title)
{
    QueueNode node = QueueNode(title);


}

