#include "QueueList.h"
QueueList::QueueList()
{
    std::string title = "";
    Queue n = Queue(10);
    QueueList *next = NULL;
    QueueList *previous = NULL;
}

QueueList::QueueList(std::string ttl)
{
    //ctor
    std::string title = ttl;
    Queue n = Queue(10);
    QueueList *next = NULL;
    QueueList *previous = NULL;
}

QueueList::~QueueList()
{
    //dtor
}

void QueueList::addQueueList(Queue q, std::string title)
{
    QueueList node = QueueList(title);


}

